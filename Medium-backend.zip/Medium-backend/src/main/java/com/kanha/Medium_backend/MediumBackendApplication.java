package com.kanha.Medium_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediumBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediumBackendApplication.class, args);
	}

}
