package com.kanha.Medium_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediumBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
